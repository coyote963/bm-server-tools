preset_settings = {
    'tdm': {
        'Server': {
            "Bots" : "0",
            "Gamemode": "2",
            "MapSelection": "1",
            "Hazards": "0",
            "Powerups": "0",
            "Name": "Team Deathmatch"
        },
        'ServerMutators': {
            "CaptEnable": "1",
        }
    },
    'dm': {
        'Server': {
            "Bots" : "3",
            "Gamemode": "0",
            "MapSelection": "1",
            "Hazards": "0",
            "Powerups": "1",
            "Name": "Deathmatch"
        }
    },
}